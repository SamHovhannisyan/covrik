const shopData = [
  {
    id: 1,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 1",
  },
  {
    id: 2,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 2",
  },
  {
    id: 3,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 3",
  },
  {
    id: 4,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 4",
  },
  {
    id: 5,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 5",
  },
  {
    id: 6,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 6",
  },
  {
    id: 7,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 7",
  },
  {
    id: 8,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 8",
  },
  {
    id: 9,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 9",
  },
  {
    id: 10,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 10",
  },
  {
    id: 11,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 11",
  },
  {
    id: 12,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 12",
  },
  {
    id: 13,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 13",
  },
  {
    id: 14,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 14",
  },
  {
    id: 15,
    img: "https://kovrik-tm.com.ua/wp-content/uploads/2019/10/kovrik-v-koridor.jpg",
    name: "Product 15",
  },
];

export default shopData;
