export default {
  BACKEND_URI: "https://heroku-kovrik-app.herokuapp.com/",
  FRONTEND_URI: "http://localhost:3000",
  ADMINISTRATOR_URI: "http://localhost:8080",
  AUTH: "aeh34284723nkasfhakj$43243824**%#432",
  PRIVATE_MESSAGE: "PRIVATE_MESSAGE",
  i18n: "i18nextLng",
};
