export const FILTERPRODUCT = "FILTERPRODUCT";
export const productGetURL = "https://kovrik.herokuapp.com/api/product"
